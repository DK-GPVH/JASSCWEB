<?php $__env->startSection('title','JASSC'); ?>

<?php $__env->startSection('content'); ?>
<div class="logocontainer container" >
    <img class="logoJASSC"src="images/LogoHome-JASSC-2021.svg"> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.clienttemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jassc2021\resources\views/welcome.blade.php ENDPATH**/ ?>