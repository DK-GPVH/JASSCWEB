@extends('layouts.clienttemplate')
@section('title','JASSC')

@section('content')
<div class="logocontainer container" >
    <img class="logoJASSC"src="images/LogoHome-JASSC-2021.svg"> 
</div>
@endsection